
$(document).ready(()=>{
    console.log("ok")
    
     $.getJSON("cine.json",function(data){
         for(let i = 0; i < data.film.length; i++){
            console.log(`${data.film[i].Image} ${data.film[i].Titre} ${data.film[i].Date} ${data.film[i].Réalisateur} ${data.film[i].Genre} ${data.film[i].Sortiedvd}`)
            let image= $("img");
             $("section").append(`</div>
             <dl>
             <dt><${data.film[i].Image}</dt>
             <dt>${data.film[i].Titre}</dt>
             <dd><b>Date : </b>${data.film[i].Date}</dd>
             <dd><b>Genre : </b>${data.film[i].Réalisateur}</dd>
             <dd><b>Réal : </b>${data.film[i].Genre}</dd>
             <dd><b>Sortie dvd : </b>${data.film[i].Sortiedvd}</dd>
            </dl>`)
				
			}
        })

})

/*let image= $(`${data.film[i].Image}`); */